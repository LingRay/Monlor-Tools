appname=httpfile
uci -q del monlor.$appname.port
uci -q del monlor.$appname.path